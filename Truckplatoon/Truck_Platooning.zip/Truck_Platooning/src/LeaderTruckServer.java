import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

public class LeaderTruckServer {
    private static final int PORT = 8080;
    private List<Socket> followerConnections = new ArrayList<>();

    public void startServer() {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Leader Truck Server is running on port " + PORT);

            while (true) {
                Socket followerSocket = serverSocket.accept();
                followerConnections.add(followerSocket);
                System.out.println("Follower connected: " + followerSocket.getInetAddress());

                // Handle follower messages in a separate thread
                new Thread(() -> handleFollowerMessages(followerSocket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleFollowerMessages(Socket followerSocket) {
        try (
                InputStream input = followerSocket.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(input))
        ) {
            String message;
            while ((message = reader.readLine()) != null) {
                System.out.println("Received from follower: " + message);
                // Process the message and broadcast updates if necessary
                broadcastMessage("Leader Truck Acknowledges: " + message);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void broadcastMessage(String message) {
        for (Socket followerSocket : followerConnections) {
            try (
                    OutputStream output = followerSocket.getOutputStream();
                    PrintWriter writer = new PrintWriter(output, true)
            ) {
                writer.println(message);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        LeaderTruckServer server = new LeaderTruckServer();
        server.startServer();
    }
}
