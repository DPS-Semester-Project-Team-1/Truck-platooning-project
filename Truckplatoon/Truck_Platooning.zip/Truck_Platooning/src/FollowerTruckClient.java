import java.io.*;
import java.net.*;

public class FollowerTruckClient {
    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 8080;

    public void startClient(String truckID) {


    }

    public static void main(String[] args) {
        FollowerTruckClient client = new FollowerTruckClient();
        client.startClient("Follower1");
    }
}
