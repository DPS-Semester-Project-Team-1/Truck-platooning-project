class FollowerTruck {
    private String truckID;
    private double currentSpeed;
    private double currentDistance;

    public FollowerTruck(String truckID, double currentSpeed, double currentDistance) {
        this.truckID = truckID;
        this.currentSpeed = currentSpeed;
        this.currentDistance = currentDistance;
    }

    public String getTruckID() {
        return truckID;
    }

    public double getCurrentSpeed() {
        return currentSpeed;
    }

    public void setCurrentSpeed(double currentSpeed) {
        this.currentSpeed = currentSpeed;
    }

    public double getCurrentDistance() {
        return currentDistance;
    }

    public void setCurrentDistance(double currentDistance) {
        this.currentDistance = currentDistance;
    }

    public void detectCar(Car car) {
        System.out.println("Follower Truck " + truckID + " detected a car passing through.");
        car.passThrough();
    }

    public void adjustDistance(double newDistance) {
        System.out.println("Follower Truck " + truckID + " adjusting distance to: " + newDistance);
        this.currentDistance = newDistance;
    }
}
