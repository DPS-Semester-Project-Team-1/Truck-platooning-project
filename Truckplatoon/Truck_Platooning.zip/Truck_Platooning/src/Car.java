class Car {
    private String carID;

    public Car(String carID) {
        this.carID = carID;
    }

    public String getCarID() {
        return carID;
    }

    public void passThrough() {
        System.out.println("Car " + carID + " is passing through the platoon.");
    }
}
