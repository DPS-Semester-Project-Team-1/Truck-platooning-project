class LeaderTruck {
    private String truckID;
    private double currentSpeed;
    private double currentDistance;
    private List<FollowerTruck> followers;

    public LeaderTruck(String truckID, double currentSpeed, double currentDistance) {
        this.truckID = truckID;
        this.currentSpeed = currentSpeed;
        this.currentDistance = currentDistance;
        this.followers = new ArrayList<>();
    }

    public String getTruckID() {
        return truckID;
    }

    public double getCurrentSpeed() {
        return currentSpeed;
    }

    public void setCurrentSpeed(double currentSpeed) {
        this.currentSpeed = currentSpeed;
    }

    public double getCurrentDistance() {
        return currentDistance;
    }

    public void setCurrentDistance(double currentDistance) {
        this.currentDistance = currentDistance;
    }


    public void broadcastStatus() {
        System.out.println("Leader Truck broadcasting status: ");
        System.out.println("Speed: " + currentSpeed + ", Distance: " + currentDistance);
        for (FollowerTruck follower : followers) {
            follower.adjustDistance(currentDistance);
        }
    }

    public void acknowledgeMessage(String message) {
        System.out.println("Leader Truck received message: " + message);
    }
}
