#include <gtest/gtest.h>
#include <thread>
#include <unistd.h>
#include "network_utils.h"

extern int setupServerV2X();  // Declaration from leaderServer.cpp
extern int setupClientConnection(const char* server_ip, int server_port);

TEST(ServerTests, ValidClientConnection) {
    // Start temporary server in a separate thread
    std::thread server_thread([]{
        int server_fd = setupServerV2X();
        sleep(1);  // Allow time for client to connect
        close(server_fd);
    });

    // Test client connection
    int client_sock = setupClientConnection("127.0.0.1", 8080);
    EXPECT_GT(client_sock, 0) << "Failed to connect to valid server";
    
    if (client_sock > 0) close(client_sock);
    server_thread.join();
}

TEST(ServerTests, InvalidPortHandling) {
    int sock = setupClientConnection("127.0.0.1", 9999);
    EXPECT_LT(sock, 0) << "Connection should fail on invalid port";
}

TEST(ServerTests, ServerDoesNotAcceptInvalidClient) {
    // Simulate invalid client connection attempt
    std::thread server_thread([]{
        int server_fd = setupServerV2X();
        sleep(2);  // Give time to test invalid client connection
        close(server_fd);
    });

    int client_sock = setupClientConnection("127.0.0.1", 12345);  // Invalid port
    EXPECT_LT(client_sock, 0) << "Server should not accept client on invalid port";

    server_thread.join();
}
