#include <gtest/gtest.h>
#include "message.h"

TEST(DefectTests, DefaultConstructor) {
    message msg;
    EXPECT_EQ(msg.messg, "") << "Default message should be empty";
    EXPECT_EQ(msg.id, 0) << "Default id should be 0";
    EXPECT_EQ(msg.timeStamp, 0) << "Default timestamp should be 0";
    EXPECT_EQ(msg.receiverPort, 0) << "Default receiverPort should be 0";
    EXPECT_EQ(msg.valid, 0) << "Default valid should be 0";
}

TEST(DefectTests, ParameterizedConstructor) {
    message msg("Test message", 1, 1000, 8080, 1);
    EXPECT_EQ(msg.messg, "Test message") << "Message text does not match";
    EXPECT_EQ(msg.id, 1) << "ID should be 1";
    EXPECT_EQ(msg.timeStamp, 1000) << "Timestamp should be 1000";
    EXPECT_EQ(msg.receiverPort, 8080) << "Receiver port should be 8080";
    EXPECT_EQ(msg.valid, 1) << "Valid should be 1";
}

TEST(DefectTests, SerializeDeserialize) {
    message original("Serialized message", 2, 1234, 9090, 1);
    char buffer[1024];  // A large enough buffer to hold the message

    original.serialize(buffer);
    
    message deserialized;
    deserialized.deserialize(buffer);
    
    EXPECT_EQ(original.messg, deserialized.messg) << "Deserialized message text mismatch";
    EXPECT_EQ(original.id, deserialized.id) << "Deserialized ID mismatch";
    EXPECT_EQ(original.timeStamp, deserialized.timeStamp) << "Deserialized timestamp mismatch";
    EXPECT_EQ(original.receiverPort, deserialized.receiverPort) << "Deserialized receiver port mismatch";
    EXPECT_EQ(original.valid, deserialized.valid) << "Deserialized valid mismatch";
}
