#include <gtest/gtest.h>
#include "message.h"

TEST(MessageTests, MessageSerialization) {
    message msg("Hello, World!", 123, 456789, 8080, 1);
    char buffer[1024];  // Buffer to hold the serialized data
    msg.serialize(buffer);

    // Verify that the serialized message can be deserialized correctly
    message msg_copy;
    msg_copy.deserialize(buffer);

    EXPECT_EQ(msg.messg, msg_copy.messg) << "Message string mismatch";
    EXPECT_EQ(msg.id, msg_copy.id) << "Message ID mismatch";
    EXPECT_EQ(msg.timeStamp, msg_copy.timeStamp) << "Timestamp mismatch";
    EXPECT_EQ(msg.receiverPort, msg_copy.receiverPort) << "Receiver port mismatch";
    EXPECT_EQ(msg.valid, msg_copy.valid) << "Valid field mismatch";
}

TEST(MessageTests, EmptyMessage) {
    message msg;
    EXPECT_EQ(msg.messg, "") << "Empty message should be empty";
    EXPECT_EQ(msg.id, 0) << "Default ID should be 0";
}
