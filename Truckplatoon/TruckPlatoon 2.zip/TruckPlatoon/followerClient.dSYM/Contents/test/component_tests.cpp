#include <gtest/gtest.h>
#include <thread>
#include <sys/socket.h>  // For ::send, ::recv
#include <unistd.h>      // For close()
#include "message.h"
#include "network_utils.h"

TEST(ComponentTest, FullMessageWorkflow) {
    // Start server components
    std::thread server_thread([]{
        int server_fd = setupServerV2X();  // Create server socket

        // Accept client connection
        struct sockaddr_in client_addr;
        socklen_t addr_len = sizeof(client_addr);
        int client_sock = accept(server_fd, (struct sockaddr*)&client_addr, &addr_len);
        ASSERT_GE(client_sock, 0) << "Failed to accept connection";

        // Receive message from client
        char buffer[1024];
        ssize_t bytes_received = ::recv(client_sock, buffer, sizeof(buffer), 0);
        ASSERT_GT(bytes_received, 0) << "No data received";

        // Deserialize and validate
        message received_msg;
        received_msg.deserialize(buffer);  // Assuming deserialize() exists in message.h
        ASSERT_EQ(received_msg.getType(), "TEST");

        close(client_sock);
        close(server_fd);
    });

    // Start client
    std::thread client_thread([]{
        int sock = setupClientConnection("127.0.0.1", 8080);
        ASSERT_GE(sock, 0) << "Failed to connect to server";

        // Create and serialize message
        message msg("TEST", 1, 0, 0, 1);  // Example constructor
        char buffer[1024];
        msg.serialize(buffer);  // Correct usage with buffer

        // Send serialized buffer
        ssize_t bytes_sent = ::send(sock, buffer, sizeof(buffer), 0);
        ASSERT_GT(bytes_sent, 0) << "Failed to send message";

        close(sock);
    });

    server_thread.join();
    client_thread.join();
}